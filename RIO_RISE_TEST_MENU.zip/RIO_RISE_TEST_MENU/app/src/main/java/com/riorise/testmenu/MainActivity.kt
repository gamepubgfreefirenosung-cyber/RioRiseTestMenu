package com.riorise.testmenu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import androidx.activity.result.contract.ActivityResultContracts
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 17, 20)
    private val panel = Color.rgb(24, 31, 35)
    private val neon = Color.rgb(86, 255, 151)
    private var handlingText: String = ""
    private var loadedName: String = "Chưa chọn handling.cfg"
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var content: LinearLayout
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readHandling(uri)
    }
    private val saveFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) saveHandling(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
    }

    private fun renderHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 18, 18, 18) }
        val header = TextView(this).apply { text = "◈ RIO RISE  /  TEST MENU"; textSize = 22f; setTextColor(neon); setPadding(0, 8, 0, 4) }
        root.addView(header)
        root.addView(TextView(this).apply { text = "ANDROID • BẢN THỬ NGHIỆM • v0.1"; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 16) })
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("TỔNG QUAN", "HANDLING", "TÍNH NĂNG").forEachIndexed { i, label ->
            tabs.addView(button(label) { when (i) { 0 -> renderHome(); 1 -> renderHandling(); else -> renderFeatures() } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)
        status = TextView(this).apply { text = "Chỉ chỉnh dữ liệu bản test mà nhà phát triển cho phép."; setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 16, 0, 12) }
        root.addView(status)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(cardTitle("MENU ĐIỀU KHIỂN"))
        content.addView(info("Menu ngoài game • Công cụ handling.cfg • Giao diện tính năng thử nghiệm"))
        content.addView(button("MỞ HANDLING.CFG") { renderHandling() })
        content.addView(button("XEM DANH SÁCH TÍNH NĂNG") { renderFeatures() })
        content.addView(info("Lưu ý: các nút farm, ESP, NoClip, aimbot và dịch chuyển là giao diện minh họa cho tới khi có API/mã tích hợp do nhà phát triển cung cấp."))
        setContentView(root)
    }

    private fun clearContent() { content.removeAllViews() }
    private fun renderHandling() {
        if (!::root.isInitialized) return
        clearContent()
        content.addView(cardTitle("HANDLING EDITOR"))
        content.addView(info(loadedName))
        content.addView(button("CHỌN FILE handling.cfg") { pickFile.launch(arrayOf("text/*", "application/octet-stream", "*/*")) })
        val velocity = edit("Hệ số Max Velocity (ví dụ 1.5)", "1.5")
        val accel = edit("Hệ số Engine Acceleration (ví dụ 1.2)", "1.2")
        content.addView(button("ÁP DỤNG HỆ SỐ VÀO BẢN SAO") {
            if (handlingText.isBlank()) { toast("Hãy chọn file handling.cfg trước"); return@button }
            val v = velocity.text.toString().toFloatOrNull(); val a = accel.text.toString().toFloatOrNull()
            if (v == null || a == null || v <= 0 || a <= 0) { toast("Nhập hệ số lớn hơn 0"); return@button }
            handlingText = transformHandling(handlingText, v, a)
            toast("Đã chỉnh bản trong bộ nhớ. Hãy xuất file mới.")
        })
        content.addView(button("XUẤT handling_test.cfg") { if (handlingText.isBlank()) toast("Chưa có dữ liệu"); else saveFile.launch("handling_test.cfg") })
        content.addView(info("Ứng dụng giữ nguyên file gốc. Hãy sao lưu và chỉ nhập file vào bản thử nghiệm theo hướng dẫn của nhà phát triển."))
    }

    private fun renderFeatures() {
        if (!::root.isInitialized) return
        clearContent()
        content.addView(cardTitle("FEATURES / TEST ONLY"))
        val groups = listOf(
            "FARM" to listOf("Farm mỏ tự động", "Farm nông trại tự động", "Farm iFood tự động", "Farm xe buýt tự động", "Farm xe tải bán tự động", "Farm xe rác bán tự động", "Chạy tự động", "Tắt va chạm"),
            "PLAYER" to listOf("Aimbot", "Máu vô hạn", "Giáp vô hạn", "NoClip", "Speed"),
            "ESP / VISUAL" to listOf("Đường tới người chơi", "Khung quanh người chơi", "Hiển thị bộ xương", "Vòng FOV"),
            "XE & DỊCH CHUYỂN" to listOf("Mở khóa xe", "Khởi động xe", "Sinh xe", "Dịch chuyển tới checkpoint", "Tùy chọn xe thử nghiệm")
        )
        groups.forEach { (group, features) ->
            content.addView(cardTitle(group))
            features.forEach { name ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(10, 5, 4, 5) }
                row.addView(TextView(this).apply { text = name; textSize = 14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
                val sw = Switch(this).apply { text = ""; isChecked = false; setOnCheckedChangeListener { _, checked -> if (checked) toast("Chỉ là công tắc giao diện: cần API tích hợp để kích hoạt $name") } }
                row.addView(sw)
                content.addView(row)
                content.addView(View(this).apply { setBackgroundColor(Color.rgb(45, 54, 58)) }, LinearLayout.LayoutParams(-1, 1))
            }
        }
        content.addView(info("Các công tắc này hiện chỉ là UI. Không có mã game/API được cung cấp nên chúng không tác động tới người chơi, bộ nhớ hay máy chủ game."))
    }

    private fun transformHandling(src: String, velFactor: Float, accelFactor: Float): String {
        // Handling.cfg GTA-style rows: numeric fields are whitespace-separated; field 13 (index 12) max velocity,
        // field 14 (index 13) engine acceleration. Preserve comments and formatting approximately.
        return src.lineSequence().joinToString("\n") { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith(";") || trimmed.startsWith("#")) return@joinToString line
            val parts = trimmed.split(Regex("\\s+")).toMutableList()
            if (parts.size < 14) return@joinToString line
            try {
                val oldV = parts[12].toFloatOrNull() ?: return@joinToString line
                val oldA = parts[13].toFloatOrNull() ?: return@joinToString line
                parts[12] = fmt(oldV * velFactor)
                parts[13] = fmt(oldA * accelFactor)
                parts.joinToString(" ")
            } catch (_: Exception) { line }
        }
    }
    private fun fmt(v: Float) = String.format(java.util.Locale.US, "%.4f", v).trimEnd('0').trimEnd('.')
    private fun readHandling(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { stream -> handlingText = BufferedReader(InputStreamReader(stream)).readText() }
            loadedName = uri.lastPathSegment ?: "handling.cfg đã chọn"
            toast("Đã đọc file. Kiểm tra đúng cấu trúc trước khi xuất.")
            renderHandling()
        } catch (e: Exception) { toast("Không đọc được file: ${e.message}") }
    }
    private fun saveHandling(uri: Uri) {
        try { contentResolver.openOutputStream(uri)?.use { OutputStreamWriter(it).use { w -> w.write(handlingText) } }; toast("Đã xuất file thử nghiệm") }
        catch (e: Exception) { toast("Không lưu được: ${e.message}") }
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; isAllCaps = false; setTextColor(neon); setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel)); setOnClickListener { action() } }
    private fun cardTitle(t: String) = TextView(this).apply { text = "▰  $t"; textSize = 16f; setTextColor(neon); setPadding(0, 18, 0, 8) }
    private fun info(t: String) = TextView(this).apply { text = t; textSize = 13f; setTextColor(Color.LTGRAY); setPadding(8, 10, 8, 12) }
    private fun edit(hintText: String, value: String): EditText = EditText(this).apply { hint = hintText; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED; setPadding(10, 4, 10, 4) }.also { content.addView(it) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
