plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.riorise.testmenu"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.riorise.testmenu"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1-test"
    }
}
