# RIO RISE TEST MENU — mã nguồn Android

Đây là **bản mẫu mã nguồn**, chưa phải APK đã biên dịch và chưa được kiểm thử trên RIO RISE.

## Đã có trong dự án
- Giao diện Android tối màu, các tab Tổng quan / Handling / Tính năng.
- Chọn `handling.cfg` bằng trình chọn tệp Android.
- Nhân cột Max Velocity và Engine Acceleration theo hệ số, sau đó xuất bản sao `handling_test.cfg`.
- Danh sách công tắc giao diện cho farm, player, ESP, xe và dịch chuyển.

## Giới hạn quan trọng
- Các công tắc farm, aimbot, máu/giáp vô hạn, NoClip, ESP, spawn xe và teleport **chỉ là giao diện minh họa**. Chúng chưa điều khiển game. Muốn triển khai phải có mã nguồn/API hoặc cơ chế mod thử nghiệm do nhà phát triển cung cấp.
- `handling.cfg` có nhiều biến thể định dạng. Bộ chỉnh đang giả định dạng GTA-style có trường 13 là Max Velocity và trường 14 là Engine Acceleration (đánh số từ 1). Hãy kiểm tra chú thích và một bản sao file thật trước khi dùng; không nhập file không xác minh vào game.
- Chưa triển khai dịch vụ menu nổi thật, chưa build APK, chưa kiểm thử trên thiết bị.

## Build APK
1. Giải nén ZIP trên máy tính.
2. Mở thư mục bằng Android Studio bản hỗ trợ Android Gradle Plugin 8.7.3.
3. Chờ Gradle Sync; cài Android SDK 35 nếu được yêu cầu.
4. Chọn **Build > Build APK(s)**.
5. APK debug thường nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## An toàn
Chỉ dùng với bản thử nghiệm và dữ liệu mà nhà phát triển cho phép chỉnh sửa. Sao lưu file gốc trước khi thay đổi.
